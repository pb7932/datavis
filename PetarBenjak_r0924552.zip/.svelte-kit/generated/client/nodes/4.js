import * as universal from "../../../../src/routes/cars/[slug]/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/cars/[slug]/+page.svelte";