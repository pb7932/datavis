import * as universal from "../../../../src/routes/cars/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/cars/+page.svelte";